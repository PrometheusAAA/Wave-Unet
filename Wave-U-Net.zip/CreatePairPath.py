# %%
import os

# Paths to your datasets (update these paths)
clean_folder = "I:/Adaptive_selection/test-clean.tar/LibriSpeech/test-clean"
noisy_folder = "I:/Adaptive_selection/Noisy _Test"
output_file = "Test_data.txt"

def get_all_flac_files(folder):
    """ Recursively find all .flac files in the given folder and return their full paths. """
    flac_files = []
    for root, _, files in os.walk(folder):
        for file in files:
            if file.endswith(".flac"):
                flac_files.append(os.path.join(root, file).replace("\\", "/"))
    return sorted(flac_files)

# Get all .flac files from both directories
clean_files = get_all_flac_files(clean_folder)
noisy_files = get_all_flac_files(noisy_folder)

# Debug information
print(f"Found {len(clean_files)} clean files and {len(noisy_files)} noisy files.")

# Ensure the same number of files in both folders
if len(clean_files) != len(noisy_files):
    print("Error: The number of files in the clean and noisy folders do not match!")
else:
    # Create the output file
    with open(output_file, "w") as file:
        for clean, noisy in zip(clean_files, noisy_files):
            file.write(f"{clean} {noisy}\n")

    print(f"Text file '{output_file}' created successfully!")

# %%
